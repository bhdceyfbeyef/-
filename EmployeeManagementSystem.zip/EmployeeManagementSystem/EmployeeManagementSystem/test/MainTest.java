import model.CommissionEmployee;
import model.Department;
import model.Employee;
import model.Gender;
import model.HourlyEmployee;
import model.MonthlyEmployee;

import java.time.LocalDate;

public class MainTest {
    public static void main(String[] args) {
        CommissionEmployee commissionEmployee = new CommissionEmployee(
                10, "Test Commission", Gender.MALE,
                LocalDate.of(2026, 1, 1),
                1000, 0.10, 5000
        );

        MonthlyEmployee monthlyEmployee = new MonthlyEmployee(
                11, "Test Monthly", Gender.FEMALE,
                LocalDate.of(2026, 2, 1),
                3000, 22, 0.05, true
        );

        HourlyEmployee hourlyEmployee = new HourlyEmployee(
                12, "Test Hourly", Gender.MALE,
                LocalDate.of(2026, 3, 1),
                20, 45, 30
        );

        Department department = new Department(
                1, "Testing", commissionEmployee, null
        );

        department.addEmployee(commissionEmployee);
        department.addEmployee(monthlyEmployee);
        department.addEmployee(hourlyEmployee);

        // Simple checks based on the implemented formulas.
        assert commissionEmployee.calculateCommission() == 500.0;
        assert commissionEmployee.calculateSalary() == 1500.0;
        assert monthlyEmployee.calculateSalary() == 3150.0;
        assert monthlyEmployee.calculateAdditionalVacation() == 1;
        assert hourlyEmployee.calculateSalary() == 950.0;
        assert department.findEmployee(11) == monthlyEmployee;
        assert department.calculateTotalPayroll() == 5600.0;

        System.out.println("All tests passed successfully.");
    }
}
