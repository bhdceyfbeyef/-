import model.CommissionEmployee;
import model.Department;
import model.Employee;
import model.Gender;
import model.HourlyEmployee;
import model.MonthlyEmployee;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

        CommissionEmployee commissionEmployee = new CommissionEmployee(
                1,
                "Ahmed",
                Gender.MALE,
                LocalDate.of(2024, 1, 10),
                5000,
                0.05,
                30000
        );

        MonthlyEmployee monthlyEmployee = new MonthlyEmployee(
                2,
                "Mona",
                Gender.FEMALE,
                LocalDate.of(2023, 6, 15),
                8000,
                25,
                0.10,
                true
        );

        HourlyEmployee hourlyEmployee = new HourlyEmployee(
                3,
                "Omar",
                Gender.MALE,
                LocalDate.of(2025, 2, 1),
                100,
                45,
                150
        );

        Department department = new Department(
                101,
                "Sales",
                commissionEmployee,
                null
        );

        department.addEmployee(commissionEmployee);
        department.addEmployee(monthlyEmployee);
        department.addEmployee(hourlyEmployee);

        System.out.println("===== Employee Management System =====");
        System.out.println();

        System.out.println("Commission Employee:");
        System.out.println(commissionEmployee);
        System.out.println("Commission = " + commissionEmployee.calculateCommission());
        System.out.println();

        System.out.println("Monthly Employee:");
        System.out.println(monthlyEmployee);
        System.out.println("Additional vacation days = "
                + monthlyEmployee.calculateAdditionalVacation());
        System.out.println();

        System.out.println("Hourly Employee:");
        System.out.println(hourlyEmployee);
        System.out.println();

        System.out.println("Department:");
        System.out.println(department);
        System.out.println("All employees:");
        department.printAllEmployees();
        System.out.println();

        System.out.println("Employee with ID 2: "
                + department.findEmployee(2).getName());

        System.out.println("Total payroll = "
                + department.calculateTotalPayroll());
    }
}
